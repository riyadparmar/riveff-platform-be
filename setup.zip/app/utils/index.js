const mongodb = require('./lib/mongodb');

module.exports = {
    mongodb,
};