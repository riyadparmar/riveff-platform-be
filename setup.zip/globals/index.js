global.emitter = require('./lib/emitter');
global.log = require('./lib/log');
global.messages = require('./lib/message');